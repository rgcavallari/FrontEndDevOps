from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Simula um banco de dados
cadastro = []

@app.route('/inserir', methods=['POST'])
def inserir():
    dados = request.json
    if not dados.get("nome") or not dados.get("email") or not dados.get("RA"):
        return jsonify({"erro": "Todos os campos são obrigatórios!"}), 400
    cadastro.append(dados)
    return jsonify({"mensagem": "Usuário cadastrado com sucesso!"})

@app.route('/consultar', methods=['GET'])
def consultar():
    return jsonify(cadastro)

@app.route('/atualizar', methods=['PUT'])
def atualizar():
    dados = request.json
    for usuario in cadastro:
        if usuario["RA"] == dados["RA"]:
            usuario["nome"] = dados["nome"]
            usuario["email"] = dados["email"]
            return jsonify({"mensagem": "Usuário atualizado com sucesso!"})
    return jsonify({"erro": "Usuário não encontrado!"}), 404

@app.route('/deletar', methods=['DELETE'])
def deletar():
    global cadastro
    RA = request.args.get("RA")
    cadastro = [usuario for usuario in cadastro if usuario["RA"] != RA]
    return jsonify({"mensagem": "Usuário removido com sucesso!"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
