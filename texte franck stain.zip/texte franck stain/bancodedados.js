document.addEventListener("DOMContentLoaded", () => {
    const API_URL = "http://127.0.0.1:5000";
    const form = document.getElementById("formCadastro");
    const listaUsuarios = document.getElementById("listaUsuarios");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const nome = document.getElementById("nome").value;
        const email = document.getElementById("email").value;
        const RA = document.getElementById("RA").value;

        const response = await fetch(`${API_URL}/inserir`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome, email, RA })
        });

        if (response.ok) {
            form.reset();
            carregarUsuarios();
        } else {
            alert("Erro ao cadastrar usuário!");
        }
    });

    async function carregarUsuarios() {
        const response = await fetch(`${API_URL}/consultar`);
        const usuarios = await response.json();
        listaUsuarios.innerHTML = "";
        usuarios.forEach(usuario => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${usuario.nome}</td>
                <td>${usuario.email}</td>
                <td>${usuario.RA}</td>
                <td>
                    <button onclick="editarUsuario('${usuario.RA}')">✏️ Editar</button>
                    <button class="delete" onclick="deletarUsuario('${usuario.RA}')">🗑️ Excluir</button>
                </td>
            `;
            listaUsuarios.appendChild(tr);
        });
    }

    window.editarUsuario = async (RA) => {
        const novoNome = prompt("Novo nome:");
        const novoEmail = prompt("Novo email:");

        if (novoNome && novoEmail) {
            const response = await fetch(`${API_URL}/atualizar`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ RA, nome: novoNome, email: novoEmail })
            });

            if (response.ok) {
                carregarUsuarios();
            } else {
                alert("Erro ao atualizar usuário!");
            }
        }
    };

    window.deletarUsuario = async (RA) => {
        if (confirm("Tem certeza que deseja excluir este usuário?")) {
            const response = await fetch(`${API_URL}/deletar?RA=${RA}`, { method: "DELETE" });

            if (response.ok) {
                carregarUsuarios();
            } else {
                alert("Erro ao deletar usuário!");
            }
        }
    };

    carregarUsuarios();
});
